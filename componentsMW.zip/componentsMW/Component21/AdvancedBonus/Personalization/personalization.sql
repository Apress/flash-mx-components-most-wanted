CREATE TABLE members (
  ID smallint(6) NOT NULL auto_increment,
  user text NOT NULL,
  password text NOT NULL,
  lastvisit text NOT NULL,
  expiredate text NOT NULL,
  credits text NOT NULL,
  percentage text,
  offerend text,
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

INSERT INTO members VALUES (1, 'demo', 'demo', 'October 20th 2002', 'February 20th 2003', '3', '15', 'February 10th 2003');