<?

// mySQL connection details
$host = "localhost"; 
$username_db = ""; 
$password_db = ""; 
$database = ""; 

// connect to the mySQL server
$server = mysql_connect($host, $username_db, $password_db) or die("&error=Error connecting to mySQL server!"); 

// connect to the mySQL database
$connection = mysql_select_db($database, $server) or die("&error=Error connecting to mySQL database!"); 

if(!isset($username) || !isset($password)) {
	print "&error=No username and/or password was provided!";
}
$result = mysql_query("SELECT * FROM members WHERE user = '".$username."' AND password = '".$password."'") or die("&error=Error checking password!");
if(mysql_num_rows($result) != 0) {
	print "&correct=true";
} else {
	print "&error=Incorrect username and/or password!";
}

?>