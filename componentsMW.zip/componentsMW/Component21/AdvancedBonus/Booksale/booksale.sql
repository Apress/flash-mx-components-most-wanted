CREATE TABLE booksale (
  ID smallint(6) NOT NULL auto_increment,
  book text NOT NULL,
  price text NOT NULL,
  stock text NOT NULL,
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

INSERT INTO booksale VALUES (1,"Flash MX Most Wanted Components","$39.99","10");