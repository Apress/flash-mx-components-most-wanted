<?
//---------------------------------------------------//
// queryTool v1.0 - written by Peter Elst            //
// www.peterelst.com - info@peterelst.com            //
//                                                   //
// read install.txt for more information             //
//---------------------------------------------------//

// mySQL connection details
$host = "localhost"; 
$username = ""; 
$password = ""; 
$database = ""; 

// connect to the mySQL server
$server = mysql_connect($host, $username, $password) or die("&error=Error connecting to mySQL server!"); 

// connect to the mySQL database
$connection = mysql_select_db($database, $server) or die("&error=Error connecting to mySQL database!"); 

// 
if(!isset($query)) {
print "&error=No query was specified!";
}
$query = stripslashes(urldecode($query));
$result = mysql_query($query) or die("&error=Error executing query!");
$array = mysql_fetch_assoc($result);

foreach($array as $name=>$value) {
print "&".$name."=".$value;
}

mysql_close($server); 
?>