CREATE TABLE english (
  ID smallint(6) NOT NULL auto_increment,
  title text NOT NULL,
  text text NOT NULL,
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

CREATE TABLE fran�ais (
  ID smallint(6) NOT NULL auto_increment,
  title text NOT NULL,
  text text NOT NULL,
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

CREATE TABLE deutsch (
  ID smallint(6) NOT NULL auto_increment,
  title text NOT NULL,
  text text NOT NULL,
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

INSERT INTO english VALUES (1, 'Macromedia Flash MX', 'Macromedia Flash MX is the fastest way to create rich Internet content and applications with a better return on investment. Powerful video, multimedia, and application development features allow the creation of rich user interfaces, online advertising, e-learning courses, and enterprise application front-ends. Deploy consistently to over 474 million Internet users across all major platforms and devices with the leading rich client, Macromedia Flash Player.');

INSERT INTO fran�ais VALUES (1, 'Macromedia Flash MX', 'Macromedia Flash MX est l�outil de cr�ation de contenu et d�applications multim�dia pour Internet offrant le meilleur retour sur investissement. Ses puissantes fonctions de d�veloppement d�applications, d�int�gration de vid�o et de multim�dia vous permettront de cr�er des interfaces utilisateur, des publicit�s en ligne, des cours eFormation et des interfaces d�applications d�entreprise. D�ployez vos applications dans la plus grande coh�rence, � plus de 474 milions d\'internautes, et sur les plates-formes, les navigateurs et les p�riph�riques les plus divers gr�ce � Macromedia Flash Player, le meilleur client multim�dia.');

INSERT INTO deutsch VALUES (1, 'Macromedia Flash MX', 'Macromedia Flash MX ist die schnellste Art, auf kosteng�nstige Weise multimediale Internet-Inhalte und -Anwendungen zu erstellen. Leistungsf�hige Video-, Multimedia- und Anwendungsentwicklungsfunktionen erm�glichen das Erstellen von umfangreichen Benutzeroberfl�chen, Online-Werbeauftritten, interaktiven Schulungskursen und Frontends f�r Unternehmensanwendungen. Ihre Inhalte werden mehr als 474 Millionen Internetbenutzern auf allen wichtigen Plattformen und Ger�ten im Macromedia Flash Player, dem f�hrenden Multimedia-Client, in exakt der von Ihnen gew�nschten Weise dargestellt.');