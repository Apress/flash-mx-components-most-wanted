<?php
$filename = "events.xml";
$fp = fopen( $filename,"w");
fwrite ( $fp, "$HTTP_RAW_POST_DATA" );
fclose( $fp );
?>
