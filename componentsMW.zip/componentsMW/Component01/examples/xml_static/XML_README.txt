---------------------------------
Please note that events.xml stores dates in year-month-day form and that
the months count from zero to eleven. So January is 0, February is 1, March
is 3, through to December being 11. This is because Flash stores months with
a zero-based numbering system.
---------------------------------