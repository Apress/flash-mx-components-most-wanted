********Please note**********

The fonts used in these example files are all included here. They will need to be installed onto a windows system if the source files are viewed and then recompiled.

The swfs include the embeded fonts and will render correctly without
installing the fonts.

cheers,

p